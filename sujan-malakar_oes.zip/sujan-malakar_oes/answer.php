<?php
include ("user.php");
$ans = new users;
$answer=$ans->answer($_POST);
$total=$ans->totalrow();
$parsent=($answer['right']*100)/$total;
$tmark=($answer['right']*5);
 ?>
 <!DOCTYPE html>
 <html>
   <head>
     <meta charset="utf-8">
     <title></title>
     <link rel="stylesheet" href="css/answer.css">
     <script type="text/javascript">
       function printLayer(layer)
       {
         var generator=window.open(",'name,");
         var layetext = document.getElementById(layer);
         generator.document.write(layetext.innerHTML.replace("Print Me"));

         generator.document.close();
         generator.print();
         generator.close();
       }
     </script>
   </head>
   <body>
      <a href="index.php"><button type="button" name="button"> Go Home</button></a><br>
  <br><br>
     <!-- content section are start hare -->

     <div class="" id="div-id-name">

       <div class="title">

            <center>
                <img src="img/1.png" alt="" class="logo"/><br>
               <h1 style="color:#ff0080">Online Examination System</h1>
               <h2 style="color:blue">Your Exam Result......................</h2>
       </div>

 </center>
     <center>
       <table border="0">
         <tr>
           <td style="color:olive">Total Questions :</td>
           <td style="color:olive"> <?php echo $total  ?></td>
         </tr>
         <tr>
           <td style="color:orange">Total Mark:</td>
           <td style="color:orange"> <?php echo $tmark  ?></td>
         </tr>
         <tr>
           <td style="color:green">Right Answer :</td>
           <td style="color:green"> <?php echo $answer['right']; ?></td>
         </tr>
         <tr>
           <td style="color:red">Wrong Answer :</td>
           <td style="color:red"><?php echo $answer['wrong']; ?> </td>
         </tr>
         <tr>
           <td style="color:black">No Answer  :</td>
           <td style="color:black"> <?php echo $answer['no_answer']; ?></td>
         </tr>
         <tr>
           <td style="color:yellow">Parcent  :</td>
           <td style="color:yellow"> <?php echo $parsent ?> %</td>
         </tr>
         <tr>
           <td colspan="2" style="color:blue">
             <?php
             if ($parsent>=40) {
               echo "You Are <b><i> Pass </b></i> In This Exam";
             }else {
               echo "You Are <b><i> Fail </b></i> In This Exam";
             }
              ?>
           </td>
         </tr>
       </table>
<br>

      <button type="button" name="button" class="button" onclick="javascript:printLayer('div-id-name')">Print Result</button>
   </center>
 </div>

   </body>
 </html>
