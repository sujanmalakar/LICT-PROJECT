<?php
session_start();
class users{
      public  $host="localhost";
      public  $user= "bdj22sujanlictpr";
      public  $password="6OCa*?JrqIUL";
      public  $dbname="bdj22suj_oes";
      public  $conn;
      public  $test;
      public  $qus;

      public function __construct()
      {
          $this->conn=new mysqli ($this->host,$this->user,$this->password,$this->dbname);
          if ($this->conn->connect_errno)
          {
            die("databases connection failed".$this->conn->connect_errno);
          }
      }

      public function test_show()
      {
        $query=$this->conn->query("select * from tests WHERE `visible`=1 ");
        while ($row=$query->fetch_array(MYSQLI_ASSOC))
        {
          $this->test[]=$row;
        }
        return $this-> test;
      }
      public function ques_show($qus)
      {
        $query=$this->conn->query("select * from questions WHERE `test_name`='$qus' ORDER BY RAND() ");
        while ($row=$query->fetch_array(MYSQLI_ASSOC))
        {
          $this->qus[]=$row;
        }
        return $this->qus;
      }
      public function answer($data)
      {
        $ans=implode("",$data);
        $right=0;
        $wrong=0;
        $no_answer=0;
        $query=$this->conn->query("select id,true_ans from questions WHERE `test_name`='".$_SESSION['test']."'");
        while ($qust=$query->fetch_array(MYSQLI_ASSOC))
        {
          if ($qust['true_ans']==$_POST[$qust['id']]) {
            $right++;
          }elseif ($_POST[$qust['id']]=="notans") {
            $no_answer++;
          }else {
            $wrong++;
          }
        }
        $array=array();
        $array['right']=$right;
        $array['wrong']=$wrong;
        $array['no_answer']=$no_answer;
        return $array;



      }
      public function totalrow()
      {
        $query=$this->conn->query("select * from questions WHERE `test_name`='".$_SESSION['test']."'");
        $total=  $query->num_rows;
        return $total;
      }
      public function url($url)
      {
        header ("location:.$url");
      }
  }
?>
