
<?php
require('session.php');
include("selectsub.html");
$user='bdj22sujanlictpr';
$password='6OCa*?JrqIUL';
$ip='localhost';
$dbname='bdj22suj_oes';

 $connection_read =mysqli_connect($ip,$user,$password,$dbname);
   if(!mysqli_connect_errno()){

     $query = "SELECT * FROM subject";

     $result = mysqli_query($connection_read, $query);
       if($result){

          echo "<table id='tb1'>";
          echo "<br>";
         while($row = mysqli_fetch_array($result, MYSQLI_BOTH)){
           echo "<tr>";
           echo "<td>"."<a href=exam.php style=font-size:40px
           style=text-decoration: none>".ucwords($row['sub_name'])."<img src=img/Plus.png style=width:150px>"."</a>"."</br>"."</br>"."</th>";
           echo "</tr>";
         }
         echo "</table>";

       }
   }else {
     die("ERROR :".mysqli_connect_errno());
   }
   mysqli_close($connection_read);

 ?>
