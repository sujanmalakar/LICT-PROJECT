<?php
//require('session.php');
include ("user.php");
$profile = new users;
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>OES</title>
     <link rel="stylesheet" href="css/exam.css" >
</head>
<body>
  <!-- content section are start hare -->
  <div class="head">
        <div class="banner">

        </div>
        <div class="title">
                <h2>Online Examination System</h2>
        </div>
        <div class="logo">
                  <img src="img/1.png" alt="" />
        </div>
  </div>

<h1>Select Your Test For Exam</h1>
    <!-- content section are start hare -->
      <a href="logout.php">
        <img src="img/logout.png" alt="" style="width: 123px;float: left;right: 0px;margin-right: 20px;position: absolute;">
      </a>
    </div>
    <div class="content">
      <div class="sublist">

        <form  action="nowexam.php" method="post">

    <!--  <label for="">Select Your Exam :</label>-->
            <select name="test" required>
              <option value="">select Any Test</option>
              <?php
                $profile->test_show();
                foreach (  $profile->test as $testname) { ?>
                  <option value="<?php echo $testname['name']?>"><?php echo $testname['name']?></option>
                <?php  }?>
            </select>
     <input type="submit"  value="Start Exam"></center>
          </form>
      </div>

    </div>

    <script type="text/javascript">
  	function ShowDate(){
  	alert("Sorry Test Not Added !");
  	}
  	</script>
  </body>
</html>
