<?php
//require('session.php');
require "usercomment.html";
 ?>
 <?php
 if(isset($_POST['submit'])){
   $user='bdj22sujanlictpr';
   $password='6OCa*?JrqIUL';
   $ip='localhost';
   $dbname='bdj22suj_oes';

 $name=$_POST['name'];
 $phone=$_POST['phone'];
 $comment=$_POST['comment'];

 $connection=mysqli_connect($ip,$user,$password,$dbname);
 if(!mysqli_connect_errno()){
  //echo "Connection to Database is Successfull!";

 $query="INSERT INTO usercomment(`name`,`phone`,`comment`)
 VALUES('{$name}','{$phone}','{$comment}')";
 if(mysqli_query($connection,$query)){
   //echo"Data Inserted into the Database Successfully!";
 }else{
   echo "Database Inserted Failed";
 }
 }else{
   die("ERROR:".mysqli_connect_error());
 }
 mysqli_close($connection);
 }
?>
/*
// READ DATA FROM DATABASE USEING PHP
$user= 'root';
$password='';
$ip='localhost';
$dbname='sujan_malakar';

$connection_read =mysqli_connect($ip,$user,$password,$dbname);
  if(!mysqli_connect_errno()){
    $query = "SELECT * FROM usercomment";
    $result = mysqli_query($connection_read, $query);
      if($result){
        echo "<table id='tb1'>
        <tr>
          <th>Sl. No. </th>
          <th>Name </th>
          <th>Phone Number</th>
          <th>Comment</th>
        </tr>";
        $sl_no=0;
        while($row = mysqli_fetch_array($result, MYSQLI_BOTH)){
          $sl_no = $sl_no + 1;
          echo "<tr>";
          echo "<td>".$sl_no."</td>";
          echo "<td>".$row['name']."</td>";
          echo "<td>".$row['phone']."</td>";
          echo "<td>".ucwords($row['comment'])."</td>";
          echo "</tr>";
        }
        echo "</table>";
      }
  }else {
    die("ERROR :".mysqli_connect_errno());
  }
  mysqli_close($connection_read);

?>
