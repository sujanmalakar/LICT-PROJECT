<?php
session_start();
if(isset($_POST['submit'])) {
  $ip ='localhost';
  $username = 'root';
  $password = '';
  $dbname = 'sujan_malakar';
  $visibility = 1;
  $connection = mysqli_connect($ip, $username, $password, $dbname);
  $myusername = mysqli_real_escape_string($connection,$_POST['login']);
  $mypassword = mysqli_real_escape_string($connection,$_POST['pass']);
  $sql = "SELECT `user_id` FROM user WHERE `login`= '{$myusername}' and `pass` = '{$mypassword}' AND `visible` = '{$visibility}'";
  $result = mysqli_query($connection,$sql);
  $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
  $active = $row['active'];
  $count = mysqli_num_rows($result);
  // If result matched $myusername and $mypassword, table row must be 1 row
  if($count == 1) {
    $_SESSION['login_user'] = $myusername;
    header("location: onlineexamsystem.php");
  }else {
    echo "<script>alert('Your Login id or Password is invalid');</script>";
  }
}
?>
<?php
require('index.html');
?>
