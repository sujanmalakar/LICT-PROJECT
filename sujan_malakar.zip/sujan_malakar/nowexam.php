<?php
//require('session.php');
include ("user.php");
$qus = new users;
$test=$_POST['test'];
$qus-> ques_show($test);
$_SESSION['test']=$test;

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Online Examination System</title>
    <link rel="stylesheet" href="css/nowexamss.css" >

  </head>
  <body>


    <!-- content section are start hare -->
<div class="head">
 <div class="banner">

 </div>
 <div class="title">
         <h2>Online Examination System</h2>
 </div>
 <div class="logo">
           <img src="img/1.png" alt="pic" class="logo"/>
 </div>
</div>

<!-- body -->
<h1>Examination...........</h1>


      <a href="logout.php">
        <img src="img/logout.png" alt="" style="width: 123px;float: left;right: 0px;margin-right: 20px;position: absolute;">
      </a>

    </div>


    <div class="content ">
      <div class="sublist">


             <form  action="answer.php" method="post">
              <?php $sl_no=1; ?>
             <?php foreach ($qus->qus as $qust) { ?>
                     <table>
                       <tr>
                         <td><?php echo "$sl_no"; ?>. <?php echo $qust['ques_name']; ?></td>
                       </tr>

                       <?php if (isset($qust['ans1'])) {?>
                       <tr>
                         <td>&emsp;&emsp;A.&emsp; <input type="radio" name="<?php echo $qust['id']; ?>" value="1"> <?php echo $qust['ans1']; ?></td>
                       </tr>
                         <?php }?>
                         <?php if (isset($qust['ans2'])) {?>
                       <tr>
                         <td>&emsp;&emsp;B.&emsp; <input type="radio" name="<?php echo $qust['id']; ?>" value="2">  <?php echo $qust['ans2']; ?> </td>
                       </tr>
                         <?php }?>
                         <?php if (isset($qust['ans3'])) {?>
                       <tr>
                         <td>&emsp;&emsp;C.&emsp;<input type="radio" name="<?php echo $qust['id']; ?>" value="3"> <?php echo $qust['ans3']; ?></td>
                       </tr>
                         <?php }?>
                         <?php if (isset($qust['ans4'])) {?>
                       <tr>
                         <td>&emsp;&emsp;D.&emsp;<input type="radio" name="<?php echo $qust['id']; ?>" value="4"> <?php echo $qust['ans4']; ?></td>
                       </tr>
                         <?php }?>
                         <tr>
                           <td><input type="radio" checked="checked" style="display:none;" name="<?php echo $qust['id']; ?>" value="notans"> </td>
                         </tr>
                     </table>
                     <br>

             <?php $sl_no ++ ; } ?>
             <center> <input type="submit" name="Get_Result" value="Submit Exam" class="submit"> </center>
             </form>

      </div>

    </div>



    </div>


    <script type="text/javascript">
  	function ShowDate(){
  	alert("Sorry Test Not Added !");
  	}
  	</script>
  </body>
</html>
