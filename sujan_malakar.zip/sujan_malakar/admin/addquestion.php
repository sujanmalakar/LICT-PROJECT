<?php
require('adminsession.php');
if(isset($_POST['submit'])){
$user='root';
$password='';
$ip='localhost';
$dbname='sujan_malakar';
$subn=$_POST['sub'];
$testn=$_POST['test'];
$qname=$_POST['ques'];
$ans1=$_POST['ans1'];
$ans2=$_POST['ans2'];
$ans3=$_POST['ans3'];
$ans4=$_POST['ans4'];
$tans=$_POST['tans'];
$connection=mysqli_connect($ip,$user,$password,$dbname);
if(!mysqli_connect_errno()){
  $visibility = 1;
 //echo "Connection to Database is Successfull!";
$query="INSERT INTO questions (`sub_name`,`test_name`,`ques_name`,`ans1`,`ans2`,`ans3`,`ans4`,`true_ans`,`visibility`)
VALUES('{$subn}','{$testn}','{$qname}','{$ans1}','{$ans2}','{$ans3}','{$ans4}','{$tans}','{$visibility}')";
if(mysqli_query($connection,$query)){
  //echo"Data Inserted into the Database Successfully!";
}else{
  echo "Database Inserted Failed";
}
}else{
  die("ERROR:".mysqli_connect_error());
}
mysqli_close($connection);
}
require("addquestion.html");
?>
