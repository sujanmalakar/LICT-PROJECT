<?php
require('adminsession.php');
if(isset($_POST['submit'])){
$user='root';
$password='';
$ip='localhost';
$dbname='sujan_malakar';
$tname=$_POST['testname'];
$allow=$_POST['testname'];

$connection=mysqli_connect($ip,$user,$password,$dbname);
if(!mysqli_connect_errno()){
 //echo "Connection to Database is Successfull!";
$visibility = 1;
$query="INSERT INTO tests( `name`,`allow`,`visible`)
VALUES('{$tname}','{$allow}','{$visibility}')";
if(mysqli_query($connection,$query)){
    echo "<script>alert('Database Insert Successfull');</script>";
}else{
  echo "Database Inserted Failed";
}
}else{
  die("ERROR:".mysqli_connect_error());
}
mysqli_close($connection);
}
require("addtest.html");

?>
