<?php
session_start();
$ip ='localhost';
$username = 'root';
$password = '';
$dbname = 'sujan_malakar';
$user_check = $_SESSION['login_user'];
$connection = mysqli_connect($ip, $username, $password, $dbname);
$ses_sql = mysqli_query($connection,"SELECT `login` FROM user WHERE `login` = '{$user_check}' ");
$row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
$login_session = $row['login'];
if(!isset($_SESSION['login_user'])){
  header("location:adminlogin.php");
}
?>
