<?php
require('adminsession.php');
if(isset($_POST['submit'])){
$user='root';
$password='';
$ip='localhost';
$dbname='sujan_malakar';
$subname=$_POST['name'];

$connection=mysqli_connect($ip,$user,$password,$dbname);
if(!mysqli_connect_errno()){
      $visibility = 1;
  //echo "Connection to Database is Successfull!";

$query="INSERT INTO subject(`sub_name`,`visibility`)
VALUES('{$subname}',$visibility)";
if(mysqli_query($connection,$query)){
  //echo"Data Inserted into the Database Successfully!";
}else{
  echo "Database Inserted Failed";
}
}else{
  die("ERROR:".mysqli_connect_error());
}
mysqli_close($connection);
}
require("addsubject.html");
?>
