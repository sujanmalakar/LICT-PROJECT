<?php
if(isset($_POST['submit'])){
$user='root';
$password='';
$ip='localhost';
$dbname='sujan_malakar';
$login=$_POST['login'];
$name=$_POST['name'];
$email=$_POST['email'];
$phone =$_POST['phone'];
$psw =$_POST['pass1'];
$city =$_POST['city'];
$address =$_POST['address'];
$gen =$_POST['gender'];

$connection=mysqli_connect($ip,$user,$password,$dbname);
if(!mysqli_connect_errno()){
 //echo "Connection to Database is Successfull!";
 $visibility =1;
$query="INSERT INTO user(`username`,`login`,`email`,`phone`,`Pass`,`city`,`address`,`gender`,`visible`)
VALUES('{$name}','{$login}','{$email}','{$phone}','{$psw}','{$city}','{$address}','{$gen}','{$visibility}')";
if(mysqli_query($connection, $query)){
  echo "<b><script>alert('SUCCESS :Your account create successfully');</script></b>";
  echo "<script>window.location.href = 'index.php'</script>";
  //echo"Data Inserted into the Database Successfully!";
}else{
  echo "Database Inserted Failed";
}
}else{
  die("ERROR:".mysqli_connect_error());
}
mysqli_close($connection);
}
require("nusersignup.html");
?>
