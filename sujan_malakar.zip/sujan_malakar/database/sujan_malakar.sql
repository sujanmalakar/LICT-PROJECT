-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 05, 2018 at 02:30 PM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sujan_malakar`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `loginid` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `loginid`, `pass`) VALUES
(1, 'admin', 'rahul');

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE `question` (
  `que_id` int(5) NOT NULL,
  `test_id` int(5) DEFAULT NULL,
  `que_desc` varchar(150) DEFAULT NULL,
  `ans1` varchar(75) DEFAULT NULL,
  `ans2` varchar(75) DEFAULT NULL,
  `ans3` varchar(75) DEFAULT NULL,
  `ans4` varchar(75) DEFAULT NULL,
  `true_ans` int(1) DEFAULT NULL,
  `visible` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`que_id`, `test_id`, `que_desc`, `ans1`, `ans2`, `ans3`, `ans4`, `true_ans`, `visible`) VALUES
(1, 1, 'The shortcut key for renaming file and folder is:', '  F2', ' F4', '  F3', '    F6 ', 1, 1),
(2, 2, '\r\nVolatile Memory is:', '    ROM', ' PROM', '   Cache Memory', ' RAM ', 4, 1),
(3, 3, 'Which of the following protocol is used to access Webpages on World Wide Web?', ' HTTP', ' Gopher', '  HTML', 'TCP/IP ', 1, 1),
(4, 4, 'CSS stands for:', ' Cascading Style Shots', ' Cascading Style Sheets', '  Creative Style Shots', '   Creative Style Sheets ', 2, 1),
(5, 5, 'What is the full form of WWW?', ' World Wide Web', '  Web World Whole', '  World Whole Web', '    Web World Wide ', 1, 1),
(6, 6, 'SQL is a (n) :', '     Structured Language	', '  Object oriented language', '  Unstructured Language', '    Software ', 1, 1),
(7, 7, 'What is the full form of PDF?', '     Printed Document Format', '    Public Document Format', '  Portable Document Format', '    Published Document Format ', 3, 1),
(8, 8, 'A bit can be _______ .', '1 only', '1 or 0 ', '1 and 0', '0 only', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `sub_name` varchar(50) NOT NULL,
  `test_name` varchar(50) NOT NULL,
  `ques_name` varchar(200) NOT NULL,
  `ans1` varchar(100) NOT NULL,
  `ans2` varchar(100) NOT NULL,
  `ans3` varchar(100) NOT NULL,
  `ans4` varchar(100) NOT NULL,
  `true_ans` int(1) NOT NULL,
  `visibility` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `sub_name`, `test_name`, `ques_name`, `ans1`, `ans2`, `ans3`, `ans4`, `true_ans`, `visibility`) VALUES
(1, 'computer Basic', 'LICT-project exam', 'What is html ?', 'tag', 'design', 'language', 'markup language', 4, 5),
(2, 'computer Basic', 'LICT-project exam', 'What is java script ?', 'langage', 'script', 'script language', 'programming language', 3, 5),
(3, 'computer Basic', 'LICT-project exam', 'Why we use linebreak tage ?', 'For line break.', 'For create line.', 'For Create underline .', 'For create overline.', 1, 5),
(4, 'computer Basic', 'LICT-project exam', 'Personal Computers are also known as:', '1.Microcomputer ', '2.Mainframes', '3.Minicomputer', '4.Microprocessor', 1, 5),
(5, 'computer Basic', 'LICT-project exam', 'What is the full form of PDF?', '1.Printed Document Format', '2.Public Document Format', '3.Portable Document Format	', '4.Published Document Format ', 3, 5),
(6, 'computer Basic', 'LICT-project exam', 'What is HTML ?', '1.programing Language.', '2. Murckup Language.', '3.Script Language.', '4.Style language.', 2, 5),
(7, 'computer Basic', 'LICT-project exam', 'Who is sujan?', 'Student', 'Trainer', 'Visitor', 'Examner', 1, 5),
(8, 'html $Css', 'Basic  Computer', 'What is Laravel?', 'programming language', 'scripting lang', 'server site lang', 'client site lagn', 1, 5),
(9, 'computer Basic', 'LICT-project exam', 'Who is suman ?', 'Trainner.', 'Student.', 'monitor.', 'Other', 1, 5),
(11, 'html $Css', 'Basic  Computer', 'What is Python ?', 'Programing Language', 'Script Language', 'Programing & Script Language', 'None of this ?', 3, 5),
(12, 'html $Css', 'Basic  Computer', 'What is header ?', 'On top text.', 'On buttom text.', 'middile text.', 'none ', 1, 5),
(13, 'html $Css', 'Basic  Computer', 'What does PHP stand for?', 'Personal Hypertext Processor', 'Hypertext Preprocessor', 'Private Home Page', 'none of the above', 1, 5),
(15, 'html $Css', 'Basic  Computer', 'All variables in PHP start with which symbol?', ' $', '&', ' !', 'none of the above', 1, 5),
(16, 'html $Css', 'Basic  Computer', 'The PHP syntax is most similar to:', 'JavaScript', 'VBScript', ' Perl and C', 'none of the above', 1, 5),
(17, 'Php&Laravel', 'Html&Css', 'what is php..?', 'hipertext preprosor', 'hipertext  preprocessor', 'hiper preeprocessor', 'hipertext preprocessorp', 2, 1),
(18, 'Php&Laravel', 'Html&Css', 'Black color code...?', '#000000', '#ffffff', '#0000ff', '#ff0000', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `login` varchar(20) DEFAULT NULL,
  `test_id` int(5) DEFAULT NULL,
  `test_date` date DEFAULT NULL,
  `score` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `sub_id` int(5) NOT NULL,
  `sub_name` varchar(25) DEFAULT NULL,
  `visibility` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`sub_id`, `sub_name`, `visibility`) VALUES
(1, 'computer Basic', '1'),
(2, 'html $Css', '1'),
(3, 'Php &Laravel', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tests`
--

CREATE TABLE `tests` (
  `id` int(5) NOT NULL,
  `name` varchar(50) NOT NULL,
  `allow` int(2) NOT NULL,
  `visible` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tests`
--

INSERT INTO `tests` (`id`, `name`, `allow`, `visible`) VALUES
(1, 'LICT-project exam', 0, 1),
(2, 'Basic  Computer', 0, 1),
(3, 'Html&Css', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(5) NOT NULL,
  `login` varchar(20) DEFAULT NULL,
  `pass` varchar(20) DEFAULT NULL,
  `username` varchar(30) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `city` varchar(15) DEFAULT NULL,
  `phone` int(10) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `visible` int(11) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `login`, `pass`, `username`, `address`, `city`, `phone`, `email`, `gender`, `visible`, `timestamp`) VALUES
(1, 'admin', 'admin', 'sujan  malakar', 'dinajpur', 'Rangpur', 1751222481, 'sujan@gmail.com', 'male', 1, '2018-03-05 02:20:39'),
(2, 'sujan', '12345', 'rahul', 'dinajpur', 'Dhaka', 1751222481, 'rahul@gmail.com', 'male', 1, '2018-03-05 12:28:33'),
(3, 'sdfsdf', 'sdfsdf', 'efsd', 'dfgdfgdf', 'Kumilla', 543453543, 'dfsd@gsdfdsf', 'female', 1, '2018-03-05 13:03:35');

-- --------------------------------------------------------

--
-- Table structure for table `useranswer`
--

CREATE TABLE `useranswer` (
  `sess_id` varchar(80) DEFAULT NULL,
  `test_id` int(11) DEFAULT NULL,
  `que_des` varchar(200) DEFAULT NULL,
  `ans1` varchar(50) DEFAULT NULL,
  `ans2` varchar(50) DEFAULT NULL,
  `ans3` varchar(50) DEFAULT NULL,
  `ans4` varchar(50) DEFAULT NULL,
  `true_ans` int(11) DEFAULT NULL,
  `your_ans` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `usercomment`
--

CREATE TABLE `usercomment` (
  `name` varchar(20) DEFAULT NULL,
  `phone` int(11) DEFAULT NULL,
  `comment` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usercomment`
--

INSERT INTO `usercomment` (`name`, `phone`, `comment`) VALUES
('sujan malakar', 1751222481, 'thanks');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`que_id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`sub_id`);

--
-- Indexes for table `tests`
--
ALTER TABLE `tests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `question`
--
ALTER TABLE `question`
  MODIFY `que_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `sub_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tests`
--
ALTER TABLE `tests`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
