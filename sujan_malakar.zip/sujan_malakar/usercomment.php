<?php
//require('session.php');
require "usercomment.html";
 ?>
 <?php
 if(isset($_POST['submit'])){
   $user='root';
   $password='';
   $ip='localhost';
   $dbname='sujan_malakar';
 $name=$_POST['name'];
 $phone=$_POST['phone'];
 $comment=$_POST['comment'];

 $connection=mysqli_connect($ip,$user,$password,$dbname);
 if(!mysqli_connect_errno()){
  //echo "Connection to Database is Successfull!";

 $query="INSERT INTO usercomment(`name`,`phone`,`comment`)
 VALUES('{$name}','{$phone}','{$comment}')";
 if(mysqli_query($connection,$query)){
   //echo"Data Inserted into the Database Successfully!";
 }else{
   echo "Database Inserted Failed";
 }
 }else{
   die("ERROR:".mysqli_connect_error());
 }
 mysqli_close($connection);
 }
?>
