<?php
 require("result.html");
?>
