<?php
include ("user.php");
$ans = new users;
$answer=$ans->answer($_POST);
$total=$ans->totalrow();
$parsent=($answer['right']*100)/$total;
$tmark=($answer['right']*5);
 ?>
 <!DOCTYPE html>
 <html>
   <head>
     <meta charset="utf-8">
     <title></title>
     <link rel="stylesheet" href="css/answer.css">
     <script type="text/javascript">
       function printLayer(layer)
       {
         var generator=window.open(",'name,");
         var layetext = document.getElementById(layer);
         generator.document.write(layetext.innerHTML.replace("Print Me"));

         generator.document.close();
         generator.print();
         generator.close();
       }
     </script>
   </head>
   <body>
       
    <img src="img/r.jpg" alt="pic" class="pic"/>
      <a href="index.php"><button type="button" name="button"> Go Home</button></a>
 
     <!-- content section are start hare -->

     <div class="" id="div-id-name">
         
    <fieldset border="25px">
           
            <center>
                <img src="img/1.png" alt="" class="logo"/></br>
               <h1 style="color:#ff0080">Online Examination System</h1>
             <h3 style="color:blue">Lict-Project-Web-Development-Program</h3>
             <h4 style="color:red">Exam Result........................</h4>
   
    
       </center>
     <center>
       <table border="0" width="400px" height="200px" >
        
         <tr>
         <tr>
           <td style="color:#85144b">Total Questions :</td>
           <td style="color:#85144b"> <?php echo $total  ?></td>
         </tr>
            <tr>
           <td style="color: #f012be">Total Mark:</td>
           <td style="color:#f012be"> <?php echo $tmark  ?></td>
         </tr>
         <tr>
           <td style="color:green">Right Answer :</td>
           <td style="color:green"> <?php echo $answer['right']; ?></td>
         </tr>
         <tr>
           <td style="color:red">Wrong Answer :</td>
           <td style="color:red"><?php echo $answer['wrong']; ?> </td>
         </tr>
         <tr>
           <td style="color:black">No Answer  :</td>
           <td style="color:black"> <?php echo $answer['no_answer']; ?></td>
         </tr>
         <tr>
           <td style="color:#663399">Parcent  :</td>
           <td style="color:#663399"> <?php echo $parsent ?> %</td>
         </tr>
         <tr>
           <td colspan="2" style="color:red">
               <br><br>
             <?php
             if ($parsent>=40) {
               echo "You Are &nbsp;&nbsp; <b><i><u> Pass </u></i></b>&nbsp;&nbsp;In This Exam. Please...&nbsp;&nbsp;<img src=img/rose.ico style=width:60px>  ";
             }else {
               echo "You Are &nbsp;&nbsp;<i> <u> <b> Fail </b></i></u> &nbsp; &nbsp;In This Exam. Please Read Book...&nbsp;&nbsp;<img src=img/Books-1.ico style=width:60px> ";
             }
              ?>
           </td>
         </tr>
       </table>
<br>

      <button type="button" name="button" class="button" onclick="javascript:printLayer('div-id-name')">Print Result</button>
   </center>
    </fieldset>
 </div>

   </body>
 </html>
